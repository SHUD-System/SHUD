#ifndef SHUD_HPP
#define SHUD_HPP

#include "IO.hpp"

int SHUD(int argc, char *argv[]);
double SHUD(FileIn *fin, FileOut *fout);

#endif
