#include "print.hpp"
void SHUDlogo(void){
    printf ("\n");
//    printf ("___________________________________________________________________________________________\n");
//    printf ("    SSSSSSSSSSSSSSS   HHHHHHHHH     HHHHHHHHH  UUUUUUUU     UUUUUUUU  DDDDDDDDDDDDD        \n");
//    printf ("  SS:::::::::::::::S  H:::::::H     H:::::::H  U::::::U     U::::::U  D::::::::::::DDD     \n");
//    printf (" S:::::SSSSSS::::::S  H:::::::H     H:::::::H  U::::::U     U::::::U  D:::::::::::::::DD   \n");
//    printf (" S:::::S     SSSSSSS  HH::::::H     H::::::HH  UU:::::U     U:::::UU  DDD:::::DDDDD:::::D  \n");
//    printf (" S:::::S                H:::::H     H:::::H     U:::::U     U:::::U     D:::::D    D:::::D \n");
//    printf (" S:::::S                H:::::H     H:::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("  S::::SSSS             H::::::HHHHH::::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("   SS::::::SSSSS        H:::::::::::::::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("     SSS::::::::SS      H:::::::::::::::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("        SSSSSS::::S     H::::::HHHHH::::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("             S:::::S    H:::::H     H:::::H     U:::::D     D:::::U     D:::::D     D:::::D\n");
//    printf ("             S:::::S    H:::::H     H:::::H     U::::::U   U::::::U     D:::::D    D:::::D \n");
//    printf (" SSSSSSS     S:::::S  HH::::::H     H::::::HH   U:::::::UUU:::::::U   DDD:::::DDDDD:::::D  \n");
//    printf (" S::::::SSSSSS:::::S  H:::::::H     H:::::::H    UU:::::::::::::UU    D:::::::::::::::DD   \n");
//    printf (" S:::::::::::::::SS   H:::::::H     H:::::::H      UU:::::::::UU      D::::::::::::DDD     \n");
//    printf ("  SSSSSSSSSSSSSSS     HHHHHHHHH     HHHHHHHHH        UUUUUUUUU        DDDDDDDDDDDDD        \n\n");
//    printf ("                  Simulator for Hydrologic Unstructured Domains v1.0                       \n");
//    printf ("___________________________________________________________________________________________\n");
//    printf ("\n\n\n\n");
    printf("  ________________________________________________________________\n");
    printf("        ______         __    __        __    __        _______  \n");
    printf("       /      \\       /  |  /  |      /  |  /  |      /       \\ \n");
    printf("      /██████  |      ██ |  ██ |      ██ |  ██ |      ███████  |\n");
    printf("      ██ \\__██/       ██ |__██ |      ██ |  ██ |      ██ |  ██ |\n");
    printf("      ██      \\       ██    ██ |      ██ |  ██ |      ██ |  ██ |\n");
    printf("       ██████  |      ████████ |      ██ |  ██ |      ██ |  ██ |\n");
    printf("      /  \\__██ |      ██ |  ██ |      ██ \\__██ |      ██ |__██ |\n");
    printf("      ██    ██/       ██ |  ██ |      ██    ██/       ██    ██/ \n");
    printf("       ██████/        ██/   ██/        ██████/        ███████/  \n\n");
    printf("     Simulator for Hydrologic Unstructured Domains v1.0  2019   \n");
    printf("  ________________________________________________________________\n");
}


